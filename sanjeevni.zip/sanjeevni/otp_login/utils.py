# otp_login/utils.py
import random
# from twilio.rest import Client
from .models import OTP

# def generate_and_send_sms_otp(user, phone_number):
#     # Generate a 6-digit random number
#     otp_code = str(random.randint(100000, 999999))
    
#     # Save or update the OTP in the database
#     OTP.objects.update_or_create(
#         user=user,
#         defaults={'otp_code': otp_code}
#     )
    
#     # Your Twilio Trial Credentials
#     account_sid = 'ACb8ea6bed438f8cd92a7c8341d8c534c6' # Paste your SID
#     auth_token = 'b848e5fb3358e98d809c66f633619e55'              # Paste your Token
#     client = Client(account_sid, auth_token)

#     try:
#         message = client.messages.create(
#             body=f"Your verification code is {otp_code}",
#             from_='+17372508034', # Replace with your trial Twilio number
#             to=phone_number      # This MUST be the number you verified in Step 3
#         )
#         print(f"OTP sent successfully. SID: {message.sid}")
#     except Exception as e:
#         print(f"Failed to send SMS: {e}")

def generate_and_send_sms_otp(user, phone_number):
    # Generate the 6-digit random number
    otp_code = str(random.randint(100000, 999999))
    
    # Save it to the database
    OTP.objects.update_or_create(user=user, defaults={'otp_code': otp_code})
    
    # Print the code to your Django terminal window for testing
    print("\n" + "="*40)
    print(f"🚨 AROGYA HEALTH LOCAL TEST 🚨")
    print(f"Sending OTP to {phone_number}")
    print(f"Your login code is: {otp_code}")
    print("="*40 + "\n")